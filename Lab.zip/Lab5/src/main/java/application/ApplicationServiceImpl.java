package application;

import domain.Book;
import domain.LibraryRepository;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.*;

@Service
public class ApplicationServiceImpl implements ApplicationService {

    private  final Logger log = Logger.getLogger(ApplicationServiceImpl.class);

    @Autowired
    LibraryRepository repository;

    void setRepository(LibraryRepository repository) {
        this.repository = repository;
    }

    @Autowired
    Random random;

    @Autowired
    Book book;

    void setRandom(Random random) {
        this.random = random;
    }

    void setBook(Book book) {
        this.book = book;
    }

    List<String> listAuthors = Arrays.asList("Федор Достоевский","Эрих Мария Ремарк",
            "Михаил Булгаков","Александр Пушкин","Николай Гоголь","Лев Толстой","Джейн Остин",
            "Рэй Брэдбери","Агата Кристи","Эмили Бронте","Жюль Верн","Ги де Мопассан",
            "Оскар Уайльд","Уильям Шекспир","Александр Дюма");

    List<String> listGenre = Arrays.asList("Басня","Баллада","Детектив","Комедия","Повесть","Поэма",
            "Рассказ","Эпопея","Трагедия","Роман");


    //заполнение базы случайными данными
    //@Override
    @Transactional
    public void createRandomEntities(int size) {
        log.trace("Enter method createRandomEntities.Input data: "+ size);
        for(int i=0;i<size;i++) {

            book.setAuthor(listAuthors.get(random.nextInt(listAuthors.size() - 1)));
            book.setDate(random.nextInt(110) + 1900);
            book.setSize_pages(random.nextInt(1000) + 30);
            book.setGenre(listGenre.get(random.nextInt(listGenre.size() - 1)));
            repository.createEntity(book);
        }
        log.trace("Exit method createRandomEntities");

    }

    //поиск сущностей с четным идентификатором

   // @Override
   @Transactional
    public List<Book> oddEntity() {
        List<Book> result = new ArrayList<Book>();
        log.trace("Enter method oddEntity.Input data: "+ result);
        List<Book> list = repository.getLibrary();

        for (int i = 0; i < list.size(); i++) {

            if(list.get(i).getId() %2 != 0 ){

                result.add(list.get(i));
            }
        }

        log.debug(result);
        log.trace("Exit method oddEntity.");
        return result;
    }

    //поиск книг до определенного года
    //@Override
    @Transactional
    public List<Book> findOldBooks(int year){

        List<Book> resultYear = new ArrayList<Book>();

        if(year <= 0){
            return resultYear;
        }

        log.trace("Enter method findOldBooks. Input data: "+ year);
        List<Book> list = repository.getLibrary();

        for (int i = 0; i < list.size(); i++) {

           if(list.get(i).getDate() <= year){
               resultYear.add(list.get(i));
           }
        }
        log.trace("Exit method findOldBooks.");
        return resultYear;
    }
}
