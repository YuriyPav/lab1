package application;

import org.springframework.context.annotation.*;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate4.LocalSessionFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import javax.sql.DataSource;
import java.util.Properties;
import java.util.Random;


@Configuration

@ComponentScan(basePackages = {"application","domain"})
public class ObjectsConfig {

    @Bean
    public LocalSessionFactoryBean sessionFactory() {
        LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
        sessionFactory.setDataSource(dataSource());
        sessionFactory.setPackagesToScan(new String[]{"domain"});
        sessionFactory.setHibernateProperties(hibernateProperties());
        return sessionFactory;
    }

    @Bean
    public DataSource dataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("org.postgresql.Driver");
        dataSource.setUrl("jdbc:postgresql://127.0.0.1/postgres");
        dataSource.setUsername("postgres");
        dataSource.setPassword("1111");

        return dataSource;
    }

    Properties hibernateProperties() {
        return new Properties() {
            {
               setProperty("hibernate.hbm2ddl.auto", "create-drop");
               setProperty("hibernate.dialect", "org.hibernate.dialect.PostgreSQLDialect");
               setProperty("hibernate.current_session_context_class", "org.hibernate.context.internal.ThreadLocalSessionContext");
            }
        };
    }

    @Bean
    public PlatformTransactionManager txManager() {
        DataSourceTransactionManager dtm = new DataSourceTransactionManager();
        dtm.setDataSource(dataSource());
        dtm.setDefaultTimeout(30);
        return dtm;
    }

    @Bean
    public Random random(){
        return new Random();
    }


}
