package application;

import domain.Book;

import java.util.List;

public interface ApplicationService {
    void createRandomEntities(int size);
    List<Book> oddEntity();
    List<Book> findOldBooks(int year);
}
