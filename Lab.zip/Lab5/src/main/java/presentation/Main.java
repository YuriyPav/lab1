package presentation;

import application.ApplicationService;
import domain.Book;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

public class Main {

    private static final Logger log = Logger.getLogger(Main.class);


    public static void main(String[] args) {

        log.info("Application started");

        ApplicationService service = AnnotationConfig.ctx.getBean(ApplicationService.class);


        try{
            service.createRandomEntities(100);
        }
        catch (Exception e) {
            log.error("LOG Exception: ",e);
        }


        List<Book> list = new ArrayList<Book>();

        try{
           list = service.oddEntity();
        }
        catch (Exception e)
        {
            log.error("LOG Exception: ",e);
        }

        int year = 1990;
        try{
            list = service.findOldBooks(year);
        }
        catch (Exception e)
        {
            log.error("LOG Exception: ",e);
        }

        for(Book book :list)
        {
            System.out.println(book);
        }

        log.info("Application stop");
    }
}