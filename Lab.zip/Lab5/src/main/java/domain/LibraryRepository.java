package domain;

import java.util.List;

public interface LibraryRepository {
    void createEntity(Book newBook);
    void editLibrary(Book updatedEntity);
    void removeLibrary(Book updatedEntity);
    List<Book> getLibrary();
}
