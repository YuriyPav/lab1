package domain;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public class LibraryRepositoryImpl implements LibraryRepository {

    private  final Logger log = Logger.getLogger(LibraryRepositoryImpl.class);

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public void createEntity(Book newBook) {
        log.trace("Enter method createEntity. Input data: " + newBook);
        Session session = sessionFactory.getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            session.save(newBook);
        tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
        }
        log.trace("Exit method createEntity.");
    }

    @Override
    public void editLibrary(Book updatedEntity) {
        log.trace("Enter method editLibrary. Input data: " + updatedEntity);
        Session session = sessionFactory.getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            session.refresh(updatedEntity);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
        }
        log.trace("Exit method editLibrary.");

    }

    @Override
    public void removeLibrary(Book updatedEntity) {
        log.trace("Enter method removeLibrary. Input data: " + updatedEntity);
        Session session = sessionFactory.getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            session.delete(updatedEntity);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
        }
        log.trace("Exit method removeLibrary.");
    }

    @Override
    public List<Book> getLibrary() {
        log.trace("Enter method getLibrary.");
        Session session = sessionFactory.getCurrentSession();
        Transaction tx = null;
        List<Book> result = null;
        try {
            tx = session.beginTransaction();
            result = session.createCriteria(Book.class).list();
            tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
        }
        log.trace("Exit method getLibrary.");
        return result;
    }
}
