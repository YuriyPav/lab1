package application;

import domain.Book;
import domain.LibraryRepositoryImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import static org.mockito.Mockito.*;

public class ApplicationServiceTestCase {

    @Mock
    LibraryRepositoryImpl repository;

    @Before
    public void initMocks(){
        MockitoAnnotations.initMocks(this);
    }

    @Test
    //возвращает четные ли позиции
    public void testOddEntityTrue()
    {
        ApplicationServiceImpl service = new ApplicationServiceImpl();
        service.setRepository(repository);
        List<Integer> date = Arrays.asList(1900, 2000, 1993, 1983, 1700);
        List<String> listGenre = Arrays.asList("Басня","Баллада","Детектив","Комедия","Повесть");
        List<String> trueTest = Arrays.asList("Баллада","Комедия");
        //////
        List<Integer> listPages = Arrays.asList(100, 99, 365, 254, 125);
        List<String> listAuthor = Arrays.asList("Федор Достоевский","Эрих Мария Ремарк",
                "Михаил Булгаков","Александр Пушкин","Николай Гоголь");
        /////
        List<Book> bookList = createList(listGenre, date, listPages, listAuthor);

        when(repository.getLibrary()).thenReturn(bookList);
        List<Book> list = service.oddEntity();

        Assert.assertFalse(check(list, trueTest, listPages, listAuthor, date));

        verify(repository, times(1)).getLibrary();
    }

    //если нету четных
    @Test
    public void testIfNotOddEntity()
    {
        ApplicationServiceImpl service = new ApplicationServiceImpl();
        service.setRepository(repository);
        List<Integer> date = Arrays.asList(1900);
        List<String> listGenre = Arrays.asList("Басня");
        List<String> trueTest = new ArrayList<String>();
        /////////////////////////
        List<Integer> listPages = Arrays.asList(100);
        List<String> listAuthor = Arrays.asList("Федор Достоевский");
        ////////////////////////
        List<Book> bookList = createList(listGenre,date,listPages, listAuthor);

        //List<String> list, List<Integer> date, List<Integer> listPages, List<String> listAuthor
        when(repository.getLibrary()).thenReturn(bookList);
        List<Book> list = service.oddEntity();

        Assert.assertFalse(check(list, trueTest, listPages, listAuthor, date));

        verify(repository, times(1)).getLibrary();

    }

    //если пустой список
    @Test
    public void testEmptyOddEntity()
    {
        ApplicationServiceImpl service = new ApplicationServiceImpl();
        service.setRepository(repository);
        List<String> listGenre = new ArrayList<String>();
        List<String> trueTest = new ArrayList<String>();
        /////////////////
        List<Integer> listPages = Arrays.asList();
        List<String> listAuthor = Arrays.asList();
        List<Integer> date = Arrays.asList();
        ////////////////
        List<Book> bookList = createList(listGenre, new ArrayList<Integer>(), listPages, listAuthor);

        when(repository.getLibrary()).thenReturn(bookList);
        List<Book> list = service.oddEntity();

        Assert.assertFalse(check(list, trueTest, listPages, listAuthor, date));
        verify(repository, times(1)).getLibrary();
    }
//**********************
    //на правильность работы
   @Test
    public void testCorrectfindOldBooks()
    {
        ApplicationServiceImpl service = new ApplicationServiceImpl();
        service.setRepository(repository);
        List<Integer> date = Arrays.asList(1900, 2000, 1993, 1983,1000);
        List<String> listGenre = Arrays.asList("Басня","Баллада","Детектив","Комедия");
        List<String> trueTest = Arrays.asList("Басня","Детектив","Комедия","Повесть");
        //////////////////////
        List<Integer> listPages = Arrays.asList(100, 365, 254, 125,100);
        List<String> listAuthor = Arrays.asList("Федор Достоевский","Михаил Булгаков","Александр Пушкин",
                "Николай Гоголь");
        /////////////////////
        List<Book> bookList = createList(listGenre,date,listPages, listAuthor);

        when(repository.getLibrary()).thenReturn(bookList);
        List<Book> list = service.findOldBooks(1700);
        Assert.assertFalse(check(list, trueTest, listPages, listAuthor, date));

        verify(repository, times(1)).getLibrary();
    }

// если нету такого года
    @Test
    public void testIfNotYear()
    {
        ApplicationServiceImpl service = new ApplicationServiceImpl();
        service.setRepository(repository);
        List<Integer> date = Arrays.asList(1900, 2000, 1993, 1983, 1700);
        List<String> listGenre = Arrays.asList("Басня","Баллада","Детектив","Комедия","Повесть");
        List<String> trueTest = new ArrayList<String>();
        ///////////////////////
        List<Integer> listPages = Arrays.asList(100, 99, 365, 254, 125);
        List<String> listAuthor = Arrays.asList("Федор Достоевский","Эрих Мария Ремарк",
                "Михаил Булгаков","Александр Пушкин","Николай Гоголь");
        //////////////////////
        List<Book> bookList = createList(listGenre,date,listPages, listAuthor);

        when(repository.getLibrary()).thenReturn(bookList);
        List<Book> list = service.findOldBooks(1600);

        Assert.assertFalse(check(list, trueTest, listPages, listAuthor, date));

        verify(repository, times(1)).getLibrary();
    }

    //тест на отридцательный год
    @Test
    public void testNegativeYear()
    {
        ApplicationServiceImpl service = new ApplicationServiceImpl();
        service.setRepository(repository);
        List<Integer> date = Arrays.asList(1900, 2000, 1993, 1983, 1700);
        List<String> listGenre = Arrays.asList("Басня","Баллада","Детектив","Комедия","Повесть");
        List<String> trueTest = new ArrayList<String>();
        List<Integer> listPages = Arrays.asList(100, 99, 365, 254, 125);
        List<String> listAuthor = Arrays.asList("Федор Достоевский","Эрих Мария Ремарк",
                "Михаил Булгаков","Александр Пушкин","Николай Гоголь");

        List<Book> bookList = createList(listGenre,date,listPages, listAuthor);

        when(repository.getLibrary()).thenReturn(bookList);
        service.findOldBooks(-100);

        verify(repository, never()).getLibrary();
    }
//4 3 5 3 4

    private List<Book> createList(List<String> list, List<Integer> date, List<Integer> listPages, List<String> listAuthor)
    {
        List<Book> bookList = new ArrayList<Book>();
        for(int i=0;i<list.size();i++){
            bookList.add(new Book());
            bookList.get(i).setGenre(list.get(i));
            bookList.get(i).setDate(date.get(i));
/////////////////////////
            bookList.get(i).setAuthor(listAuthor.get(i));
            bookList.get(i).setSize_pages(listPages.get(i));
//////////////////
            bookList.get(i).setId(i);
        }
        return bookList;
    }

    private Boolean check(List<Book> bookList,List<String> stringList, List<Integer> listPages, List<String> listAuthor,
                          List<Integer> listDate)
    {
        Boolean flag = false;

        if(bookList.size()==stringList.size())
        {
            for(int i=0;i< bookList.size();i++)
            {
                if(!bookList.get(i).getGenre().equals(stringList.get(i))) {
                    flag = true;
                    break;
                }
                if(!bookList.get(i).getAuthor().equals(listAuthor.get(i))) {
                    flag = true;
                    break;
                }
                if(bookList.get(i).getSize_pages() != (listPages.get(i))) {
                    flag = true;
                    break;
                }
                if(bookList.get(i).getDate() == listDate.get(i)) {
                    flag = true;
                    break;
                }
            }
        }
        else
            flag=true;

        return flag;
    }
}
